package ru.fil.calculator

import java.lang.Math.abs

class MyFraction(var numerator: Int,var denominator: Int ) {
    init {
        if (denominator<0){
            denominator *= -1
            numerator *= -1
        }
        if (denominator == 0){
            throw DenominatorZeroError()
        }
    }
    fun shorten(){
        if (denominator == 1){ }
        else {
            val prime_list_num = getPrimeList(numerator)
            val prime_list_den = getPrimeList(denominator)
            var i = 0
            while (i < prime_list_num.size){
                val ai = prime_list_num[i]
                if (ai in prime_list_den){
                    prime_list_den.remove(ai)
                    prime_list_num.remove(ai)
                }
                else{i+=1}
                if (prime_list_den.size == 0){break}
            }
            if (prime_list_den.size==0){prime_list_den.add(1)}
            if (prime_list_num.size==0){prime_list_num.add(1)}
            numerator = multList(prime_list_num)
            denominator = multList(prime_list_den)
        }

    }
    fun change_den(multiplier:Int){
        numerator *= multiplier
        denominator *= multiplier
    }
}