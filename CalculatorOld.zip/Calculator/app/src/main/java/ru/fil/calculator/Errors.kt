package ru.fil.calculator

class DenominatorZeroError() : Exception()