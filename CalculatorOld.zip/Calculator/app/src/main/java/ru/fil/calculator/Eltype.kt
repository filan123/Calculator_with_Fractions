package ru.fil.calculator

enum class ItemType {
    Oper,Numb,OpenBrace,CloseBrace
}
// data число или  0 1 2 3 под операции
class ExprItem(type: ItemType,data: MyFraction,pos: Int){
}

