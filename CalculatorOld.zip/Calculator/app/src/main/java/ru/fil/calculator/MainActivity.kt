package ru.fil.calculator

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.Button
import android.view.View
import android.widget.GridLayout

class MainActivity : AppCompatActivity() {
    val list_numb = listOf("0","1","2","3","4","5","6","7","8","9",",")
    val list_oper = listOf("x", "+", "-", "/")
    val list_btn = listOf("delete","AC","fraction","*",
                        "7","8","9","+",
                        "4","5","6","-",
                        "1","2","3","/",
                        ",","0","+/-","eval")
    val buttons = mutableListOf<Int>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val expr = mutableListOf<String>()
        val message = findViewById<TextView>(R.id.Expression)
        //создаем кнопки
        val container = findViewById<GridLayout>(R.id.GridLayout2)

        for (i in 1..20){
            val button = Button(this).apply{
                text= list_btn[i-1]
                id = View.generateViewId()
                tag = list_btn[i-1]
                layoutParams = GridLayout.LayoutParams().apply {
                    columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                    rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                    width = 0
                    height = GridLayout.LayoutParams.WRAP_CONTENT
                }
            }
            container.addView(button)
            buttons.add(button.id)
        }
        // слушаем кнопки
        val listener = View.OnClickListener{ view ->
            val char = view.tag.toString()

            when (char){
                in list_numb -> if(expr.size==0){
                    expr.add(char)
                }
                else {if(expr.last() in list_oper){expr.add(char)} else{expr[expr.size-1]+=char}}
                in list_oper -> expr.add(char)
                "delete" -> if(expr.size!=0){expr.removeLast()}
                "AC" -> expr.clear()
            }

            message.text = expr.joinToString(separator = " ")
        }


        buttons.forEach { id -> findViewById<Button>(id).setOnClickListener(listener)}

    }




}
